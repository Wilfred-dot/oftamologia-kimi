# OptiCare Backend

Backend do Sistema de Gestão de Saúde Oftalmológica desenvolvido para a Universidade Católica de Moçambique.

## 🚀 Tecnologias

- **Node.js** + **TypeScript**
- **Express** - Framework web
- **Prisma ORM** - Gerenciamento de banco de dados
- **PostgreSQL** - Banco de dados relacional
- **JWT** - Autenticação
- **bcryptjs** - Criptografia de senhas

## 📋 Pré-requisitos

- Node.js 18+
- PostgreSQL 14+
- npm ou yarn

## 🔧 Instalação

1. **Clone o repositório e acesse a pasta do backend:**
```bash
cd backend
```

2. **Instale as dependências:**
```bash
npm install
```

3. **Configure as variáveis de ambiente:**
```bash
cp .env.example .env
# Edite o arquivo .env com suas configurações
```

4. **Configure o banco de dados no arquivo `.env`:**
```env
DATABASE_URL="postgresql://usuario:senha@localhost:5432/opticare?schema=public"
JWT_SECRET="sua_chave_secreta_aqui_muito_segura"
JWT_EXPIRES_IN="7d"
PORT=3001
FRONTEND_URL="http://localhost:5173"
```

5. **Execute as migrações do banco de dados:**
```bash
npx prisma migrate dev --name init
```

6. **Gere o cliente Prisma:**
```bash
npx prisma generate
```

7. **Popule o banco com dados iniciais:**
```bash
npm run db:seed
```

## ▶️ Executando o servidor

### Modo desenvolvimento:
```bash
npm run dev
```

### Modo produção:
```bash
npm run build
npm start
```

## 📚 Endpoints da API

### Autenticação
- `POST /api/auth/login` - Login de usuário
- `GET /api/auth/me` - Dados do usuário logado
- `POST /api/auth/change-password` - Alterar senha

### Dashboard
- `GET /api/dashboard/estatisticas` - Estatísticas gerais
- `GET /api/dashboard/notificacoes` - Notificações do usuário

### Pacientes
- `GET /api/pacientes` - Listar pacientes
- `GET /api/pacientes/:id` - Buscar paciente por ID
- `POST /api/pacientes` - Criar paciente
- `PUT /api/pacientes/:id` - Atualizar paciente
- `DELETE /api/pacientes/:id` - Excluir paciente
- `GET /api/pacientes/estatisticas` - Estatísticas de pacientes

### Médicos
- `GET /api/medicos` - Listar médicos
- `GET /api/medicos/:id` - Buscar médico por ID
- `POST /api/medicos` - Criar médico
- `PUT /api/medicos/:id` - Atualizar médico
- `DELETE /api/medicos/:id` - Excluir médico

### Consultas
- `GET /api/consultas` - Listar consultas
- `GET /api/consultas/:id` - Buscar consulta por ID
- `POST /api/consultas` - Criar consulta
- `PUT /api/consultas/:id` - Atualizar consulta
- `DELETE /api/consultas/:id` - Excluir consulta
- `GET /api/consultas/proximas` - Próximas consultas
- `GET /api/consultas/hoje` - Consultas de hoje
- `GET /api/consultas/estatisticas` - Estatísticas de consultas

### Exames
- `GET /api/exames` - Listar exames
- `GET /api/exames/:id` - Buscar exame por ID
- `POST /api/exames` - Criar exame
- `PUT /api/exames/:id` - Atualizar exame
- `DELETE /api/exames/:id` - Excluir exame
- `GET /api/exames/paciente/:pacienteId` - Exames por paciente
- `GET /api/exames/estatisticas` - Estatísticas de exames

### Tratamentos
- `GET /api/tratamentos` - Listar tratamentos
- `GET /api/tratamentos/:id` - Buscar tratamento por ID
- `POST /api/tratamentos` - Criar tratamento
- `PUT /api/tratamentos/:id` - Atualizar tratamento
- `DELETE /api/tratamentos/:id` - Excluir tratamento
- `GET /api/tratamentos/paciente/:pacienteId` - Tratamentos por paciente
- `GET /api/tratamentos/estatisticas` - Estatísticas de tratamentos

## 🔐 Autenticação

A API utiliza JWT para autenticação. Inclua o token no header das requisições:

```
Authorization: Bearer <seu_token_jwt>
```

## 👥 Perfis de Usuário

- **ADMIN** - Acesso total ao sistema
- **MEDICO** - Acesso a pacientes, consultas, exames e tratamentos
- **RECEPCIONISTA** - Acesso a pacientes e consultas
- **TECNICO** - Acesso a exames

## 🌱 Dados Iniciais (Seed)

O seed cria automaticamente:
- 3 usuários (admin, médico, recepcionista) - senha: `123456`
- 3 médicos com horários de trabalho
- 8 pacientes de exemplo
- 4 consultas
- 2 exames
- 2 tratamentos com medicamentos
- 2 notificações

## 🛠️ Comandos Úteis

```bash
# Desenvolvimento
npm run dev

# Build
npm run build

# Produção
npm start

# Prisma
npx prisma migrate dev      # Criar migração
npx prisma migrate deploy   # Aplicar migrações em produção
npx prisma generate         # Gerar cliente Prisma
npx prisma studio           # Abrir Prisma Studio
npm run db:seed            # Popular banco com dados iniciais
```

## 📄 Licença

Este projeto foi desenvolvido para fins acadêmicos na Universidade Católica de Moçambique.

**Estudante:** Wilfred Deloviar Júnior  
**Orientador:** Eng. Persson Domingos Abrantes  
**Ano:** 2025
